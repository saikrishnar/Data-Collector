package com.example.questioninterface;

import java.io.File;
import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

public class IdVerify extends Activity implements OnItemSelectedListener {

	SharedPreferences preference;
	Button reset;
	Spinner lang;
	EditText languageId;
	EditText speakerId;
	private String[] items = {"Select language", "English", "Hindi", "Telugu"};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		/*String filename = Environment.getExternalStorageDirectory().getAbsolutePath();
		String[] languages = new String[10];
		filename = filename + "/Questions/" + "languages.txt";
		FileInputStream fIn;
		int count = 0;
		try {
			fIn = new FileInputStream(filename);
			BufferedReader myReader = new BufferedReader( new InputStreamReader(fIn));
			String line = null;
			while((line = myReader.readLine()) != null) {
				languages[count++] = line;
				Log.d("Line......................", "................" + line);
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Toast.makeText(getApplicationContext(), "No language file loaded",
					Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} */

		preference = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		final SharedPreferences.Editor editor = preference.edit();
		//editor.clear().commit();
		setContentView(R.layout.activity_id_verify);
		//final EditText languageId = (EditText) findViewById(R.id.language_id);
		/*languageId.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, languages));
		Log.d("Adaptor-----------------", languageId.getAdapter().toString());
		languageId.setThreshold(count);*/

		Button button = (Button) findViewById(R.id.enter);
		reset = (Button) findViewById(R.id.clear);
		languageId = (EditText) findViewById(R.id.language_id);
		speakerId = (EditText) findViewById(R.id.speaker_id);

		//languageId.requestFocus();
		/*languageId.postDelayed(new Runnable() {
			@Override
			public void run() {
				InputMethodManager keyboard = (InputMethodManager)
						getSystemService(Context.INPUT_METHOD_SERVICE);
				keyboard.showSoftInput(languageId, 0);
			}
		},200); */

		//addItemsOnSpinner();
		//addListenerOnButton();
		//addListenerOnSpinnerItemSelection();

		lang = (Spinner) findViewById(R.id.lang_list);
		ArrayAdapter<String> adapter_state = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, items);
		adapter_state.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		lang.setAdapter(adapter_state);
		lang.setOnItemSelectedListener((OnItemSelectedListener) this);

		String langId = languageId.getText().toString();
		
		

		/*languageId.setOnFocusChangeListener(new OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus){
				if(hasFocus) {
					languageId.showDropDown();
				}
				else {
					languageId.dismissDropDown();
				}
			}
		});*/


	//	languageId.setOnEditorActionListener(new OnEditorActionListener() {

	//		@Override			
	//		public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
	//			boolean handled = false;
	//			if (actionId == EditorInfo.IME_ACTION_DONE) {
		
/*		languageId.setOnFocusChangeListener(new OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				boolean handled = false;
				String langId = languageId.getText().toString();
			    if(hasFocus){
					speakerId.postDelayed(new Runnable() {
						@Override
						public void run() {
							InputMethodManager keyboard = (InputMethodManager)
									getSystemService(Context.INPUT_METHOD_SERVICE);
							keyboard.hideSoftInputFromWindow(speakerId.getWindowToken(), 0);
						}
					},50);  
					int speakIdLast = preference.getInt("last_speaker_"+langId, -1);
					int next;
					String speakIdnext = "";
					if(speakIdLast == -1) {
						speakIdnext = langId + "00001";
						next = 1;
					}
					else {
						next = speakIdLast + 1;
						int temp = next;
						String str="";
						int pos = 0;
						while(temp > 0) {
							int dig = temp%10;
							String digString = Integer.toString(dig);
							str = str + digString;
							temp /= 10;
						}
						while(str.length()<5) {
							str = str + "0";
						}
						str = new StringBuilder(str).reverse().toString();
						speakIdnext = langId + str;
					}
					speakerId.setText(speakIdnext);
					handled = true;
				}
				return;
			}

		}); */

		reset.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				new AlertDialog.Builder(IdVerify.this)
				.setIcon(android.R.drawable.ic_dialog_alert)
				.setTitle("Clear User Data")
				.setMessage("Are you sure you want to reset user data? (this cannot be undone)")
				.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						editor.clear().commit();			            }

				})
				.setNegativeButton("No", null)
				.show();
			}
		});

		button.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				int flagSp = 0, flagLn = 0;
				String spkid = speakerId.getText().toString();
				String lnid = languageId.getText().toString();
				if (lnid.length() == 0){
					Toast.makeText(getApplicationContext(), "Language Id not Valid",
							Toast.LENGTH_SHORT).show();
				}
				else {
					if(spkid.length() != 7) {
						flagSp = 1;
					}
					else if(spkid.charAt(0) != lnid.charAt(0) || spkid.charAt(1) != lnid.charAt(1)) {
						flagSp = 1;
					}
					else {
						int pos = 2;
						while(pos<7) {
							if(spkid.charAt(pos) < '0' || spkid.charAt(pos) > '9') {
								flagSp = 1;
								break;
							}
							pos++;
						}
					}
					if(flagSp == 0) {
						//String mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
						//System.out.println(mFileName);
						String mFileName = lnid +"_utf8.txt";
						//System.out.println(mFileName);

						/////////////////////////

			/*			final String state = Environment.getExternalStorageState();

						if ( Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state) ) {  // we can read the External Storage...           
							//Retrieve the primary External Storage:
							final File primaryExternalStorage = Environment.getExternalStorageDirectory();

							//Retrieve the External Storages root directory:
							final String externalStorageRootDir;
							if ( (externalStorageRootDir = primaryExternalStorage.getParent()) == null ) {  // no parent...
								System.out.println("External Storage1: " + primaryExternalStorage + "\n");
							}
							else {
								final File externalStorageRoot = new File( externalStorageRootDir );
								final File[] files = externalStorageRoot.listFiles();

								for ( final File file : files ) {
									if ( file.isDirectory() && file.canRead() && (file.listFiles().length > 0) ) {  // it is a real directory (not a USB drive)...
										System.out.println("External Storage: " + file.getAbsolutePath() + "\n");
									}
								}
							}
						} */

						/////////////////////////

						File file = new File(mFileName);
						if(!file.exists()) {
							flagLn = 1;
						}
						AssetManager am = getAssets();
						boolean check = assetExists(am, mFileName);
						if (check == true) {
							flagLn = 0;
						}

					}
					if(flagSp == 0 && flagLn == 0) {
						int speakIdLast = preference.getInt("last_speaker_"+lnid, -1);
						if(speakIdLast != -1) {
							String spkidlast = Integer.toString(speakIdLast);
							while(spkidlast.length() < 5) {
								spkidlast = "0" + spkidlast;
							}
							spkidlast = lnid + spkidlast;
							if(spkidlast.compareTo(spkid) < 0) {
								int num = 0;
								for(int i=2; i<7; i++) {
									num = num*10 + spkid.charAt(i) - '0';
								}
								editor.putInt("last_speaker_"+lnid, num).commit();
							}
						}
						else {
							int num = 0;
							for(int i=2; i<7; i++) {
								num = num*10 + spkid.charAt(i) - '0';
							}
							editor.putInt("last_speaker_"+lnid, num).commit();
						}
						Intent intent = new Intent(IdVerify.this, AnswerRecord.class);
						intent.putExtra("langid", languageId.getText().toString());
						intent.putExtra("speakerid", speakerId.getText().toString()	);				
						startActivity(intent);
					}
					else if(flagSp != 0){
						Toast.makeText(getApplicationContext(), "SpeakerId not Valid",
								Toast.LENGTH_SHORT).show();
					}
					else {
						Toast.makeText(getApplicationContext(), "Language Id not valid",
								Toast.LENGTH_SHORT).show();
					}
				}
			}
		});
	}


	/*public void addItemsOnSpinner2() {

		List<String> list = new ArrayList<String>();
		list.add("list 1");
		list.add("list 2");
		list.add("list 3");
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
			android.R.layout.simple_spinner_item, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		lang.setAdapter(dataAdapter);
	  }

	public void addListenerOnSpinnerItemSelection() {
		lang.setOnItemSelectedListener(new CustomOnItemSelectedListener());
	} 

	public void addListenerOnButton() {

		la = (Spinner) findViewById(R.id.lang_list);

		btnSubmit.setOnClickListener(new OnClickListener() {

		}

		public void CustomOnItemSelectedListener implements OnItemSelectedListener {

			public void onItemSelected(AdapterView<?> parent, View view, int pos,long id) { 
						"OnItemSelectedListener : " + parent.getItemAtPosition(pos).toString(),

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
			}

		} */

	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
		lang.setSelection(position);
		String selState = (String) lang.getSelectedItem();
		if(selState == "English") {
			languageId.setText("EN");
			checkLang("EN");
		}
		//else if(selState == "Hindi") {
		//	languageId.setText("HI");
		//}
		else if(selState == "Hindi") {
			languageId.setText("HN");
			checkLang("HN");
		}
		else if(selState == "Telugu") {
			languageId.setText("TE");
			checkLang("TE");
		}
		else {
			languageId.setText("");
			speakerId.setText("");
		}
	}
	
	public static boolean assetExists(AssetManager assets, String name) {
	    try {
	        // using File to extract path / filename
	        // alternatively use name.lastIndexOf("/") to extract the path
	    	//System.out.println("here");
	        File f = new File(name);
	        String parent = f.getParent();
	        if (parent == null) parent = "";
	        String fileName = f.getName();
	        // now use path to list all files
	        String[] assetList = assets.list(parent);
	        if (assetList != null && assetList.length > 0) {
	            for (String item : assetList) {
	                if (fileName.equals(item))
	                	return true;
	            }
	        }
	    } catch (IOException e) {
	        // Log.w(TAG, e); // enable to log errors
	    }
	    return false;
	}

	public boolean checkLang(String langId) {
		boolean handled = false;
		if (langId!=null) {
		int speakIdLast = preference.getInt("last_speaker_"+langId, -1);
		int next;
		String speakIdnext = "";
		if(speakIdLast == -1) {
			speakIdnext = langId + "00001";
			next = 1;
		}
		else {
			next = speakIdLast + 1;
			int temp = next;
			String str="";
			int pos = 0;
			while(temp > 0) {
				int dig = temp%10;
				String digString = Integer.toString(dig);
				str = str + digString;
				temp /= 10;
			}
			while(str.length()<5) {
				str = str + "0";
			}
			str = new StringBuilder(str).reverse().toString();
			speakIdnext = langId + str;
		}
		speakerId.setText(speakIdnext);
		handled = true;
		}
		return handled;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_id_verify, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.help:
			startActivity(new Intent(this, Instructions.class));
			return true;
			// More items go here (if any) ...
		}
		return false;
	}


	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}

}
