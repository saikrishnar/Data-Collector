package com.example.questioninterface;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.RandomAccessFile;

import android.media.AudioFormat;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore.Files;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class AnswerRecord extends Activity {

	int pos = 0;
	Button prev, next, record, play;
	String[] questions;
	TextView qn;
	String speakerId;
	String langId;
	int count;
	SharedPreferences preference;
	SharedPreferences.Editor editor;
	boolean mStartRecording = true, mStartPlaying = true;
	AudioRecorder audioRecorder;
	MediaPlayer mPlayer;
	String mFileName;
	String tempfileName;
    String nFileName;
    String temporary;
    private RandomAccessFile randomAccessWriter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_answer_record);
		preference = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
		editor = preference.edit();
		//editor.clear().commit();
		Intent intent = getIntent();
		langId = intent.getStringExtra("langid");
		speakerId = intent.getStringExtra("speakerid");
		Log.d("speakerid-------------------------------------", speakerId);
		questions = new String[200];
		String filename = Environment.getExternalStorageDirectory().getAbsolutePath();
		File dir = new File(filename + "/Answers");
		dir.mkdirs();		
		String qfile = langId + "_utf8.txt";
		Log.d("filename-----------------------", filename);
		AssetManager am = getAssets();
		try {
			InputStream fIn = am.open(qfile);
			BufferedReader myReader = new BufferedReader( new InputStreamReader(fIn));
			String line = "";
			count = 0;
			while((line = myReader.readLine()) != null) {
				if(line.length() < 2) {
					continue;
				}
				if(line.charAt(0) == langId.charAt(0) && line.charAt(1) == langId.charAt(1)) {
					String[] arr = line.split(" ");
					questions[count] =  Integer.toString(count+1)+ "    ";
					for(int i=1; i<arr.length; i++) {
						questions[count] += arr[i] + " ";						
					}
					count++;
				}
			}
			fIn.close();
		} catch (FileNotFoundException e) { 
			// TODO Auto-generated catch block
			e.printStackTrace();
			Log.d("Exiting----------------------------","");
			finish();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		pos = preference.getInt(speakerId, -1);
		Log.d("pos----------------------", Integer.toString(pos));
		if(pos == -1 || pos == count-1) {
			pos = 0;
		}
		else {
			pos += 1;
		}
		Log.d("pos----------------------", Integer.toString(pos));
		Log.d("count--------------------", Integer.toString(count));
		prev = (Button) findViewById(R.id.previous);
		next = (Button) findViewById(R.id.next);
		record = (Button) findViewById(R.id.record);
		play = (Button) findViewById(R.id.play);

		if(pos <= 0) {
			prev.setEnabled(false);
		}
		if(pos >= count-1) {
			next.setEnabled(false);
		}

		/*prev.setEnabled(false);
		next.setEnabled(false);*/

		qn = (TextView) findViewById(R.id.question);
		qn.setText(questions[pos]);

		mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
		mFileName += "/Answers/" + langId + "_" + speakerId + "_" + Integer.toString(pos) + ".wav";
		
		nFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
		nFileName += "/Answers/" + langId + "_t_" + speakerId + "_" + Integer.toString(pos) + ".wav";
		
		tempfileName = Environment.getExternalStorageDirectory().getAbsolutePath();
		tempfileName += "/Answers/" + langId + "_tt_" + speakerId + "_" + Integer.toString(pos) + ".wav";

		File file = new File(mFileName);
		if(file.exists()) {
			play.setEnabled(true);
		}
		else {
			play.setEnabled(false);
		}

		play.setOnClickListener(new OnClickListener () {
			public void onClick(View v) {
				onPlay(mStartPlaying);
				if (mStartPlaying) {
					next.setEnabled(false);
					prev.setEnabled(false);
					record.setEnabled(false);
					play.setText("Stop");
				} else {
					play.setText("Play");
					record.setEnabled(true);
					if(pos > 0) {
						prev.setEnabled(true);
					}
					if(pos < count - 1) {
						next.setEnabled(true);
					}
				}
				mStartPlaying = !mStartPlaying;
			}		
		});


		record.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				onRecord(mStartRecording);			
				if (mStartRecording) {
					next.setEnabled(false);
					prev.setEnabled(false);
					record.setText("Stop");
				} else {
					if(pos > 0) {
						prev.setEnabled(true);
					}
					if(pos < count - 1) {
						next.setEnabled(true);
					}
					play.setEnabled(true);
					editor.putInt(speakerId, pos).commit();
					record.setText("Record");
				}
				mStartRecording = !mStartRecording;

			}
		});

		prev.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

				if(pos>0) {
					pos --;
					qn.setText(questions[pos]);
				}
				if(pos == 0) {				
					prev.setEnabled(false);
				}
				else {
					prev.setEnabled(true);
				}
				if(pos < count-1) {
					next.setEnabled(true);
				}
				mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
				mFileName += "/Answers/" + langId + "_" + speakerId + "_" + Integer.toString(pos) + ".wav";
				
				nFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
				nFileName += "/Answers/" + langId + "_t_" + speakerId + "_" + Integer.toString(pos) + ".wav";

				File file = new File(mFileName);
				if(file.exists()) {
					play.setEnabled(true);
				}
				else {
					play.setEnabled(false);
				}
			}
		});

		next.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

				if(pos<count - 1) {
					pos ++;
					qn.setText(questions[pos]);
				}
				if(pos == count-1) {				
					next.setEnabled(false);
				}
				if(pos > 0) {
					prev.setEnabled(true);
				}

				mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
				mFileName += "/Answers/" + langId + "_" + speakerId + "_" + Integer.toString(pos) + ".wav";
				
				nFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
				nFileName += "/Answers/" + langId + "_t_" + speakerId + "_" + Integer.toString(pos) + ".wav";

				File file = new File(mFileName);
				if(file.exists()) {
					play.setEnabled(true);
				}
				else {
					play.setEnabled(false);
				}
			}
		});

	}

	private void onRecord(boolean start) {
		if (start) {
			startRecording();
		} else {
			stopRecording();
		}
	}

	private void onPlay(boolean start) {
		if (start) {
			startPlaying();
		} else {
			stopPlaying();
		}
	}

	private void startPlaying() {
		mPlayer = new MediaPlayer();
		try {
			String mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
			mFileName += "/Answers/" + langId + "_" + speakerId + "_" + Integer.toString(pos) + ".wav";
			Log.d("filename----------------", mFileName);
			mPlayer.setDataSource(mFileName);
			mPlayer.prepare();
			mPlayer.start();
		//	while(mPlayer.isPlaying()) {				
		//	}
		} catch (IOException e) {
			Log.e("oiaopsid", "prepare() failed");
		}
		//return false;
	}

	private void stopPlaying() {
		mPlayer.release();
		mPlayer = null;
	}

	//private static void copyFileUsingJava7Files(File source, File dest) throws IOException {
      //  Files.copy(source.toPath(), dest.toPath());
   // }
	
	public void copy(String src, String dst) throws IOException {
		String source = src;
		String destination = dst;			
		

		File destFile = new File(destination);
		File sourceFile = new File(source);
		
	    InputStream in = new FileInputStream(sourceFile);
	    OutputStream out = new FileOutputStream(destFile);

	    // Transfer bytes from in to out
	    byte[] buf = new byte[1024];
	    int len;
	    while ((len = in.read(buf)) > 0) {
	        out.write(buf, 0, len);
	    }
	    boolean deleted = sourceFile.delete();
	    
	    out.close();
	    }
	
	
	private void startRecording() {

		//mRecorder = new MediaRecorder();
		audioRecorder = new AudioRecorder(true, MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_CONFIGURATION_MONO, AudioFormat.ENCODING_PCM_16BIT);
	/*	File from = new File(mFileName);
		tempfileName =  Environment.getExternalStorageDirectory().getAbsolutePath();
		tempfileName += "/Answers/temp";
		if(from.exists()) {		 
			System.out.println("inside ");
			audioRecorder.setOutputFile(tempfileName);
		}
		else { */
		System.out.println(mFileName);
		File temp = new File(mFileName);
		if(temp.exists()) {	
			System.out.println("Uffffffff");
			
            //System.out.println("Please"+ nFileName);
            audioRecorder.setOutputFile(langId+"_t_"+ speakerId + "_" + Integer.toString(pos));
			//System.out.println("Please"+ nFileName);
			//append(mFileName, nFileName);
			//System.out.println("Please"+ nFileName);
		 } else{
			audioRecorder.setOutputFile(langId+"_"+ speakerId + "_" + Integer.toString(pos));
		}
		/* mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mRecorder.setOutputFile(mFileName);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);*/
         

		try {
			audioRecorder.prepare();
		} catch (Exception e) {
			Log.e("lkldasd", "prepare() failed");
		}

		audioRecorder.start();
		
	//	tempfileName += ".wav";
		//System.out.println("tempfilename:"+tempfileName);
		
		
	}

	private void stopRecording() {
		audioRecorder.stop();
		File temp = new File(nFileName);
		System.out.println("hey "+ nFileName);
		if(temp.exists()){
			System.out.println("Temp exists");
			//bappend(mFileName, nFileName);
			append(mFileName, nFileName);
			//CombineWaveFile(mFileName, nFileName);
		}
		
		
		audioRecorder.release();
		/*mRecorder.stop();
	        mRecorder.release();
	        mRecorder = null;*/
	}

      

	  private void append( String... filePaths) {
		try{
			
//String Read
			String oldRecording = filePaths[0];
			String newRecording = filePaths[1];			
			
//Files Creation
			File newFile = new File(newRecording);
			File oldFile = new File(oldRecording);
			File tempFile = new File(tempfileName);			
			
//Output Stream Creation
			FileOutputStream fos = new FileOutputStream(newFile,true);
			FileOutputStream fostemp = new FileOutputStream(tempFile,true);
			FileOutputStream fos1 = new FileOutputStream(oldFile,true);
			
//Input Stream Creation
		FileInputStream oldfis = new FileInputStream(oldFile);
			byte origContent[]= new byte[(int)oldFile.length()];
			byte test1Content[]= new byte[44];
		
			
			FileInputStream newfis = new FileInputStream(newFile);
			byte fileContent[]= new byte[(int)newFile.length()];
			byte test2Content[]= new byte[44];
			
			/*for(int i=0;i<44;i++){
				oldfis.read(test1Content);
				newfis.read(test2Content);
				System.out.println(" " + i+ " " +test1Content[i] );
				System.out.println(" " + i+ " " +test2Content[i]);	} */
			String temp = langId+ "_tt_"+ speakerId + "_" + Integer.toString(pos);
			//audioRecorder.setOutputFile(temp);
			//audioRecorder.writeheader();			
		
			
			
			oldfis.read(origContent, 44, (int)oldFile.length()-44);
			//oldfis.read(origContent);		
			
			newfis.read(fileContent, 44, (int)newFile.length()-44);
			//newfis.read(fileContent);
			
            oldfis.close();
            newfis.close();
//Byte Array Stream Creation
			
			//ByteArrayInputStream original = new ByteArrayInputStream(origContent );
			//ByteArrayInputStream latest = new ByteArrayInputStream(fileContent );
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
						
			
			outputStream.write(origContent);
			outputStream.write(fileContent);
			byte c[] = outputStream.toByteArray( );
			//CombineWaveFile(nFileName,mFileName,tempfileName,origContent,fileContent);
			CombineWaveFile(nFileName,mFileName,tempfileName,c);
			//fostemp.write(fileContent);
			System.out.println("Yay");
			//fos.write(origContent);
			//outputStream.writeTo(fos);
			copy(tempfileName,mFileName);
			System.out.println("Yay");
			
			File file = new File(newRecording); 
			boolean deleted = file.delete();
			newFile.delete();
			
			System.out.println("New recording deleted after merging: " + deleted);
			
		}catch (Exception ex) {
			System.out.println("Error while merging audio file: " + ex.getMessage());
		}
		
		
	}
 
	  
	 private void fileappender(FileOutputStream out ){
		 int RECORDER_SAMPLERATE = 16000;
		 
		// int RECORDER_CHANNELS = AudioFormat.CHANNEL_IN_MONO;
		 //int RECORDER_AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT;
		 final int RECORDER_BPP=16;
		 int channels = 1;
		 long byteRate = RECORDER_BPP * RECORDER_SAMPLERATE * channels / 8;
		 long totalAudioLen = 0;
		 long totalDataLen = totalAudioLen + 36;
		 long longSampleRate = 16000;
		 
		 //audioRecorder.writeheader();
		 byte[] header = new byte[44];
		 
		    header[0] = 'R'; 
		    header[1] = 'I';
		    header[2] = 'F';
		    header[3] = 'F';
		    for(int i=4;i<8;i++){
		    	header[i] = 0;
		    }
		    header[8] = 'W';
		    header[9] = 'A';
		    header[10] = 'V';
		    header[11] = 'E';
		    header[12] = 'f'; // 'fmt ' chunk
		    header[13] = 'm';
		    header[14] = 't';
		    header[15] = ' ';
		    header[16] = 16; // 4 bytes: size of 'fmt ' chunk
		    header[17] = 0;
		    header[18] = 0;
		    header[19] = 0;
		    header[20] = 1; // format = 1
		    header[21] = 0;
		    header[22] = (byte) channels;
		    header[23] = 0;
		    header[24] = (byte) (longSampleRate & 0xff);
		    header[25] = (byte) ((longSampleRate >> 8) & 0xff);
		    header[26] = (byte) ((longSampleRate >> 16) & 0xff);
		    header[27] = (byte) ((longSampleRate >> 24) & 0xff);
		    header[28] = (byte) (byteRate & 0xff);
		    header[29] = (byte) ((byteRate >> 8) & 0xff);
		    header[30] = (byte) ((byteRate >> 16) & 0xff);
		    header[31] = (byte) ((byteRate >> 24) & 0xff);
		    header[32] = (byte) (channels * 16 / 8); // block align
		    header[33] = 0;
		    header[34] = RECORDER_BPP; // bits per sample
		    header[35] = 0;
		    header[36] = 'd';
		    header[37] = 'a';
		    header[38] = 't';
		    header[39] = 'a';
		    header[40] = (byte) (totalAudioLen & 0xff);
		    header[41] = (byte) ((totalAudioLen >> 8) & 0xff);
		    header[42] = (byte) ((totalAudioLen >> 16) & 0xff);
		    header[43] = (byte) ((totalAudioLen >> 24) & 0xff);
		    
			}  
		    
	 
	  
	  
	  
	  
	  
	  
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	  
	 

	private void playwav(byte[] SoundByteArray) 
	  {
	      try 
	      {

	          File path=new File(getCacheDir()+"/musicfile.wav");

	          FileOutputStream fos = new FileOutputStream(path);
	          fos.write(SoundByteArray);
	          fos.close();

	          MediaPlayer mediaPlayer = new MediaPlayer();

	          FileInputStream fis = new FileInputStream(path);
	          mediaPlayer.setDataSource(getCacheDir()+"/musicfile.wav");

	          mediaPlayer.prepare();
	          mediaPlayer.start();
	          //mediaPlayer.release();
	         
	      } 
	      catch (IOException ex) 
	      {   
	          String s = ex.toString();
	          ex.printStackTrace();
	      }
	  }
	  
	  
	
	  
	  
	  
	  
	  
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	  
	  
	  
	  public void CombineWaveFile(String file1, String file2,String file3,byte[] d) 
		 {
		  
		     FileInputStream in1 = null, in2 = null;
		     final int RECORDER_BPP=16; //8,16,32..etc
		     int RECORDER_SAMPLERATE=16000; //8000,11025,16000,32000,48000,96000,44100..et
		     FileOutputStream out = null;
		     long totalAudioLen = 0;
		     long totalDataLen = totalAudioLen + 36;
		     long longSampleRate = RECORDER_SAMPLERATE;
		     int channels = 1;  //mono=1,stereo=2
		     long byteRate = RECORDER_BPP * RECORDER_SAMPLERATE * channels / 8;

		     int bufferSize=1024;
		  byte[] data = new byte[bufferSize];


		     try {
		         in1 = new FileInputStream(file1);
		         in2 = new FileInputStream(file2);
		         
		       
		         out = new FileOutputStream(file3);

		         totalAudioLen = in1.getChannel().size() + in2.getChannel().size();
		         
		      

		         totalDataLen = totalAudioLen + 36;

		         WriteWaveFileHeader(out, totalAudioLen, totalDataLen,
		         longSampleRate, channels, byteRate,RECORDER_BPP);
                 System.out.println("Hip Hip");
                 out.write(d);
                 System.out.println("Hip Hip");
                 
		      

		     //    Toast.makeText(this, "Done!!", Toast.LENGTH_LONG).show();
		     } catch (FileNotFoundException e) {
		         e.printStackTrace();
		     } catch (IOException e) {
		         e.printStackTrace();
		     }
		 }

	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
		 private void WriteWaveFileHeader(FileOutputStream out, long totalAudioLen,
		 long totalDataLen, long longSampleRate, int channels, long byteRate, int RECORDER_BPP)
		 throws IOException {

		     byte[] header = new byte[44];

		     header[0] = 'R';
		     header[1] = 'I';
		     header[2] = 'F';
		     header[3] = 'F';
		     header[4] = (byte)(totalDataLen & 0xff);
		     header[5] = (byte)((totalDataLen >> 8) & 0xff);
		     header[6] = (byte)((totalDataLen >> 16) & 0xff);
		     header[7] = (byte)((totalDataLen >> 24) & 0xff);
		     header[8] = 'W';
		     header[9] = 'A';
		     header[10] = 'V';
		     header[11] = 'E';
		     header[12] = 'f';
		     header[13] = 'm';
		     header[14] = 't';
		     header[15] = ' ';
		     header[16] = 16;
		     header[17] = 0;
		     header[18] = 0;
		     header[19] = 0;
		     header[20] = 1;
		     header[21] = 0;
		     header[22] = (byte) channels;
		     header[23] = 0;
		     header[24] = (byte)(longSampleRate & 0xff);
		     header[25] = (byte)((longSampleRate >> 8) & 0xff);
		     header[26] = (byte)((longSampleRate >> 16) & 0xff);
		     header[27] = (byte)((longSampleRate >> 24) & 0xff);
		     header[28] = (byte)(byteRate & 0xff);
		     header[29] = (byte)((byteRate >> 8) & 0xff);
		     header[30] = (byte)((byteRate >> 16) & 0xff);
		     header[31] = (byte)((byteRate >> 24) & 0xff);
		     header[32] = (byte)(1* 16 / 8);
		     header[33] = 0;
		     header[34] = (byte) RECORDER_BPP;
		     header[35] = 0;
		     header[36] = 'd';
		     header[37] = 'a';
		     header[38] = 't';
		     header[39] = 'a';
		     header[40] = (byte)(totalAudioLen & 0xff);
		     header[41] = (byte)((totalAudioLen >> 8) & 0xff);
		     header[42] = (byte)((totalAudioLen >> 16) & 0xff);
		     header[43] = (byte)((totalAudioLen >> 24) & 0xff);
             System.out.println("here");
		     out.write(header,0,44);
		     
		 }
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 private void writeWaveFileHeader(ByteArrayOutputStream out, long totalAudioLen,
				 long totalDataLen, long longSampleRate, int channels, long byteRate, int RECORDER_BPP)
				 throws IOException {

				     byte[] header = new byte[44];

				     header[0] = 'R';
				     header[1] = 'I';
				     header[2] = 'F';
				     header[3] = 'F';
				     header[4] = (byte)(totalDataLen & 0xff);
				     header[5] = (byte)((totalDataLen >> 8) & 0xff);
				     header[6] = (byte)((totalDataLen >> 16) & 0xff);
				     header[7] = (byte)((totalDataLen >> 24) & 0xff);
				     header[8] = 'W';
				     header[9] = 'A';
				     header[10] = 'V';
				     header[11] = 'E';
				     header[12] = 'f';
				     header[13] = 'm';
				     header[14] = 't';
				     header[15] = ' ';
				     header[16] = 16;
				     header[17] = 0;
				     header[18] = 0;
				     header[19] = 0;
				     header[20] = 1;
				     header[21] = 0;
				     header[22] = (byte) channels;
				     header[23] = 0;
				     header[24] = (byte)(longSampleRate & 0xff);
				     header[25] = (byte)((longSampleRate >> 8) & 0xff);
				     header[26] = (byte)((longSampleRate >> 16) & 0xff);
				     header[27] = (byte)((longSampleRate >> 24) & 0xff);
				     header[28] = (byte)(byteRate & 0xff);
				     header[29] = (byte)((byteRate >> 8) & 0xff);
				     header[30] = (byte)((byteRate >> 16) & 0xff);
				     header[31] = (byte)((byteRate >> 24) & 0xff);
				     header[32] = (byte)(2 * 16 / 8);
				     header[33] = 0;
				     header[34] = (byte) RECORDER_BPP;
				     header[35] = 0;
				     header[36] = 'd';
				     header[37] = 'a';
				     header[38] = 't';
				     header[39] = 'a';
				     header[40] = (byte)(totalAudioLen & 0xff);
				     header[41] = (byte)((totalAudioLen >> 8) & 0xff);
				     header[42] = (byte)((totalAudioLen >> 16) & 0xff);
				     header[43] = (byte)((totalAudioLen >> 24) & 0xff);

				     out.write(header);
				     
				 }
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_answer_record, menu);
		return true;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	protected Void bappend(String... filePaths) {
		try {
			
//String Read
			String oldRecording = filePaths[0];
			String newRecording = filePaths[1];			
			
//Files Creation
			File newFile = new File(newRecording);
			File oldFile = new File(oldRecording);
			File tempFile = new File(tempfileName);
			
			
//Output Stream Creation
			FileOutputStream fos = new FileOutputStream(newFile,true);
			FileOutputStream fostemp = new FileOutputStream(tempFile,true);
			FileOutputStream fos1 = new FileOutputStream(oldFile,true);
			
//Input Stream Creation
		FileInputStream fiso = new FileInputStream(oldFile);
			byte origContent[]= new byte[(int)oldFile.length()];
			fiso.read(origContent);		// contents of first recording
			fiso.close();			
			
			
			FileInputStream fisn = new FileInputStream(newFile);
			byte fileContent[]= new byte[(int)newFile.length()];
			fisn.read(fileContent);    //Contents of fresh recording
			fisn.close();
			//fos1.write(fileContent);
			
		    

//Skip Headers
			//System.out.println(origContent.length);
			//skip(original);
			//System.out.println(origContent.length);
			//skip(latest);	
			byte[] headerlessFileContent = new byte[fileContent.length-44];
			for(int j=44; j<fileContent.length;j++){
				headerlessFileContent[j-44] = fileContent[j];
			}
			fileContent = headerlessFileContent;
			
			byte[] headerlessorigContent = new byte[origContent.length-44];
			for(int j=44; j<origContent.length;j++){
				headerlessorigContent[j-44] = origContent[j];
			}
			origContent = headerlessorigContent;
			

			
			
//Generate ByteArrayStreams
			byte[] origi = new byte[origContent.length-44];
		//	original.read(origi);
			System.out.println(origi.length);
			byte[] lates = new byte[fileContent.length-44];
		//	original.read(lates);
			
		
			
			
//Header Dimensions
			final int RECORDER_BPP=16; //8,16,32..etc
		    int RECORDER_SAMPLERATE=16000; //8000,11025,16000,32000,48000,96000,44100..et
			long totalAudioLen = 0;
		    long totalDataLen = totalAudioLen + 36;
		    long longSampleRate = 16000;
		    int channels = 1;  //mono=1,stereo=2
		    long byteRate = RECORDER_BPP * RECORDER_SAMPLERATE * channels / 8;
			//WriteWaveFileHeader(fostemp, totalAudioLen, totalDataLen,
			  //    longSampleRate, channels, byteRate,RECORDER_BPP);
		    fileappender( fostemp );
			 
			//audioRecorder.setOutputFile(tempfileName);
			//audioRecorder.writeheader();
			
//Appending the wave Files
		//	outputStream.write( origi );
		//	outputStream.write( lates );			
		//	byte c[] = outputStream.toByteArray( );
			
//Play the wave File
			//playwav( c );
		
//Save the waveFile
			//outputStream.writeTo(fostemp);
			fostemp.write(origi); 
			//fos.write(c);
			//fos.close();
			fostemp.close();
			//copy(tempFile,newFile);
			
			//Checking Comments			
			//System.out.println("please");
			//System.out.println("New recording deleted after merging: " + deleted);
			//System.out.println("Successfully merged the two Voice Message Recordings");
			//System.out.println("Length of outputFile after merging: " + last.length());
			
		} 
//Exception
		
		catch (Exception ex) {
			System.out.println("Error while merging audio file: " + ex.getMessage());
		}
		return null;
	}	
	  

}