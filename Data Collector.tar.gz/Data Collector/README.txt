README

* There should be a file named 'languages.txt' in the folder sdcard/Questions which contains the language ids in each line.
* There should a folder named 'Answers' present in the sdcard.
* All the question files should be named <languageid>_utf8.txt and be present in the sdcard/Questions folder
* The 'Reset' button clears all the user logs but doesn't clear the recorded wav files.
